/**
 * Type definitions for @mercuryworkshop/epoxy-transport
 */

declare module "@mercuryworkshop/epoxy-transport" {
  /** Path to the epoxy transport files */
  export const epoxyPath: string;
}
